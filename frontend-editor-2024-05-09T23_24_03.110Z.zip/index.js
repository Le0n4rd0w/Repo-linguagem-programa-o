//função que será chamada quando o botão for clicado
function handleClick(){
  alert("o botao foi clicado!!!!!!")
}
//adiciona um event listner ao botao
document.getElementById("action").addEventListener
("click", handleClick);

